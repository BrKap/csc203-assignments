class ScannerException
   extends Exception
{
}

